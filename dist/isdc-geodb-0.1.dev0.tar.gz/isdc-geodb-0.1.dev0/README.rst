========
APP_NAME
========

APP_DESC

Mandatory Module for ASDC

Quick start
-----------

1. Add "APP_NAME" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'APP_NAME',
    ]

    If necessary add "APP_NAME" in (check comment for description): 
        DASHBOARD_PAGE_MODULES, 
        GETRISKEXECUTEEXTERNAL_MODULES, 
        QUICKOVERVIEW_MODULES, 
        MAP_APPS_TO_DB_CUSTOM

    For development in virtualenv add APP_NAME_PARENT_DIR path to venv_name/bin/activate:
        export PYTHONPATH=${PYTHONPATH}:\
        ${HOME}/APP_NAME_PARENT_DIR

2. Include the APP_NAME URLconf in geonode/urls.py like this::

    url('', include('APP_NAME.urls')),

3. Run `python manage.py migrate APP_NAME` to create the APP_NAME models.

