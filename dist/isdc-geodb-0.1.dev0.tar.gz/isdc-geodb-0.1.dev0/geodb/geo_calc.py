from geodb.models import (
    AfgAdmbndaAdm1,
    AfgAdmbndaAdm2,
    AfgAirdrmp,
    # AfgAvsa,
    AfgCapaGsmcvr,
    AfgCaptAdm1ItsProvcImmap,
    AfgCaptAdm1NearestProvcImmap,
    AfgCaptAdm2NearestDistrictcImmap,
    AfgCaptAirdrmImmap,
    AfgCaptHltfacTier1Immap,
    AfgCaptHltfacTier2Immap,
    AfgCaptHltfacTier3Immap,
    AfgCaptHltfacTierallImmap,
    # AfgFldzonea100KRiskLandcoverPop, 
    AfgHltfac,
    # AfgIncidentOasis,
    AfgLndcrva,
    AfgPplp,
    AfgRdsl,
    districtsummary,
    # earthquake_events,
    # earthquake_shakemap,
    # FloodRiskExposure, 
    # forecastedLastUpdate, 
    LandcoverDescription,
    provincesummary,
    tempCurrentSC,
    # villagesummaryEQ,
    )
import json
import time, datetime
from tastypie.resources import ModelResource, Resource
from tastypie.serializers import Serializer
from tastypie import fields
from tastypie.constants import ALL
from django.db.models import Count, Sum, F, When, Case
from django.core.serializers.json import DjangoJSONEncoder
from tastypie.authorization import DjangoAuthorization
from urlparse import urlparse
from geonode.maps.models import Map
from geonode.maps.views import _resolve_map, _PERMISSION_MSG_VIEW
from django.db import connection, connections
from itertools import *
# addded by boedy
from matrix.models import matrix
from tastypie.cache import SimpleCache
from pytz import timezone, all_timezones
from django.http import HttpResponse

from djgeojson.serializers import Serializer as GeoJSONSerializer

from geodb.geoapi import getRiskNumber

from graphos.sources.model import ModelDataSource
from graphos.renderers import flot, gchart
from graphos.sources.simple import SimpleDataSource
from django.test import RequestFactory
import urllib2, urllib
import pygal
from geodb.radarchart import RadarChart
# from geodb.riverflood import getFloodForecastBySource

from django.utils.translation import ugettext as _
# from securitydb.models import SecureFeature
import pprint

#added by razinal
import pickle
import visvalingamwyatt as vw
from shapely.wkt import loads as load_wkt
from vectorformats.Formats import Django, GeoJSON
from vectorformats.Feature import Feature
from vectorformats.Formats.Format import Format

# ISDC
from geonode.utils import include_section, none_to_zero, query_to_dicts, RawSQL_nogroupby
from django.conf import settings

import importlib

def getCommonUse(request,flag, code):
    response = {}
    response['parent_label']=_('Custom Selection')
    response['qlinks']=_('Select provinces')
    response['adm_child'] = []
    response['adm_prov'] = []
    response['adm_dist'] = []
    # response['parent_label_dash']='Custom Selection'

    # if flag == 'entireAfg':
    #     response['parent_label']='Afghanistan'
    #     response['parent_label_dash']='Afghanistan'
    # elif flag == 'currentProvince':
    #     if code<=34:
    #         lblTMP = AfgAdmbndaAdm1.objects.filter(prov_code=code)
    #         response['parent_label_dash'] = 'Afghanistan - '+lblTMP[0].prov_na_en
    #         response['parent_label'] = lblTMP[0].prov_na_en
    #     else:
    #         lblTMP = AfgAdmbndaAdm2.objects.filter(dist_code=code)
    #         response['parent_label_dash'] = 'Afghanistan - '+ lblTMP[0].prov_na_en + ' - ' +lblTMP[0].dist_na_en
    #         response['parent_label'] = lblTMP[0].dist_na_en

    main_resource = AfgAdmbndaAdm1.objects.all().values('prov_code','prov_na_en').order_by('prov_na_en')
    # clusterPoints = AfgAdmbndaAdm1.objects.all()
    response['parent_label_dash']=[]
    if flag == 'entireAfg':
        response['parent_label']=_('Afghanistan')
        response['parent_label_dash'].append({'name':_('Afghanistan'),'query':'','code':0})
        response['qlinks']=_('Select province')
        resource = main_resource
        # clusterPoints = AfgAdmbndaAdm1.objects.all()
        for i in resource:
            response['adm_child'].append({'code':i['prov_code'],'name':i['prov_na_en']})
    elif flag == 'currentProvince':
        if code<=34:
            lblTMP = AfgAdmbndaAdm1.objects.filter(prov_code=code)
            response['parent_label_dash'].append({'name':_('Afghanistan'),'query':'','code':0})
            response['parent_label_dash'].append({'name':lblTMP[0].prov_na_en,'query':'&code='+str(code),'code':code})
            response['parent_label'] = lblTMP[0].prov_na_en
            response['qlinks']=_('Select district')
            resource = AfgAdmbndaAdm2.objects.all().values('dist_code','dist_na_en').filter(prov_code=code).order_by('dist_na_en')
            # clusterPoints = AfgAdmbndaAdm2.objects.all()
            for i in resource:
                response['adm_child'].append({'code':i['dist_code'],'name':i['dist_na_en']})
            for i in main_resource:
                response['adm_prov'].append({'code':i['prov_code'],'name':i['prov_na_en']})
        else:
            lblTMP = AfgAdmbndaAdm2.objects.filter(dist_code=code)
            response['parent_label_dash'].append({'name':_('Afghanistan'),'query':'','code':0})
            response['parent_label_dash'].append({'name':lblTMP[0].prov_na_en,'query':'&code='+str(lblTMP[0].prov_code),'code':lblTMP[0].prov_code})
            response['parent_label_dash'].append({'name':lblTMP[0].dist_na_en,'query':'&code='+str(code),'code':code})
            response['parent_label'] = lblTMP[0].dist_na_en
            response['qlinks']=''
            for i in main_resource:
                response['adm_prov'].append({'code':i['prov_code'],'name':i['prov_na_en']})
            resource = AfgAdmbndaAdm2.objects.all().values('dist_code','dist_na_en').filter(prov_code=lblTMP[0].prov_code).order_by('dist_na_en')
            for i in resource:
                response['adm_dist'].append({'code':i['dist_code'],'name':i['dist_na_en']})
    else:
        response['parent_label_dash'].append({'name':_('Custom Selection'),'query':'','code':0})
        response['qlinks']=''

    # response['poi_points'] = []
    # for i in clusterPoints:
    #     response['poi_points'].append({'code':i.prov_code,'x':i.wkb_geometry.point_on_surface.x,'y':i.wkb_geometry.point_on_surface.y})
    return response

def getRawBaseLine(filterLock, flag, code, includes=[], excludes=[]):
    targetBase = AfgLndcrva.objects.all()
    response = {}
    parent_data = getRiskNumber(targetBase, filterLock, 'agg_simplified_description', 'area_population', 'area_sqm', 'area_buildings', flag, code, None)

    temp = dict([(c['agg_simplified_description'], c['count']) for c in parent_data])
    response['built_up_pop'] = round(temp.get('Build Up', 0) or 0,0)
    response['cultivated_pop'] = round(temp.get('Fruit Trees', 0) or 0,0)+round(temp.get('Irrigated Agricultural Land', 0) or 0,0)+round(temp.get('Rainfed', 0) or 0,0)+round(temp.get('Vineyards', 0) or 0,0)
    response['barren_pop'] = round(temp.get('Water body and Marshland', 0) or 0,0)+round(temp.get('Barren land', 0) or 0,0)+round(temp.get('Snow', 0) or 0,0)+round(temp.get('Rangeland', 0) or 0,0)+round(temp.get('Sand Covered Areas', 0) or 0,0)+round(temp.get('Forest & Shrub', 0) or 0,0)+round(temp.get('Sand Dunes', 0) or 0,0)

    response['built_up_pop_build_up'] = round(temp.get('Build Up', 0) or 0,0)
    response['cultivated_pop_fruit_trees'] = round(temp.get('Fruit Trees', 0) or 0,0)
    response['cultivated_pop_irrigated_agricultural_land'] = round(temp.get('Irrigated Agricultural Land', 0) or 0,0)
    response['cultivated_pop_rainfed'] = round(temp.get('Rainfed', 0) or 0,0)
    response['cultivated_pop_vineyards'] = round(temp.get('Vineyards', 0) or 0,0)
    response['barren_pop_water_body_and_marshland'] = round(temp.get('Water body and Marshland', 0) or 0,0)
    response['barren_pop_barren_land'] = round(temp.get('Barren land', 0) or 0,0)
    response['barren_pop_snow'] = round(temp.get('Snow', 0) or 0,0)
    response['barren_pop_rangeland'] = round(temp.get('Rangeland', 0) or 0,0)
    response['barren_pop_sand_covered_areas'] = round(temp.get('Sand Covered Areas', 0) or 0,0)
    response['barren_pop_forest_shrub'] = round(temp.get('Forest & Shrub', 0) or 0,0)
    response['barren_pop_sand_dunes'] = round(temp.get('Sand Dunes', 0) or 0,0)

    temp = dict([(c['agg_simplified_description'], c['houseatrisk']) for c in parent_data])
    response['built_up_buildings'] = temp.get('Build Up', 0) or 0
    response['cultivated_buildings'] = temp.get('Fruit Trees', 0) or 0+temp.get('Irrigated Agricultural Land', 0) or 0+temp.get('Rainfed', 0) or 0+temp.get('Vineyards', 0) or 0
    response['barren_buildings'] = temp.get('Water body and Marshland', 0) or 0+temp.get('Barren land', 0) or 0+temp.get('Snow', 0) or 0+temp.get('Rangeland', 0) or 0+temp.get('Sand Covered Areas', 0) or 0+temp.get('Forest & Shrub', 0) or 0+temp.get('Sand Dunes', 0) or 0

    response['built_up_buildings_build_up'] = round(temp.get('Build Up', 0) or 0,0)
    response['cultivated_buildings_fruit_trees'] = round(temp.get('Fruit Trees', 0) or 0,0)
    response['cultivated_buildings_irrigated_agricultural_land'] = round(temp.get('Irrigated Agricultural Land', 0) or 0,0)
    response['cultivated_buildings_rainfed'] = round(temp.get('Rainfed', 0) or 0,0)
    response['cultivated_buildings_vineyards'] = round(temp.get('Vineyards', 0) or 0,0)
    response['barren_buildings_water_body_and_marshland'] = round(temp.get('Water body and Marshland', 0) or 0,0)
    response['barren_buildings_barren_land'] = round(temp.get('Barren land', 0) or 0,0)
    response['barren_buildings_snow'] = round(temp.get('Snow', 0) or 0,0)
    response['barren_buildings_rangeland'] = round(temp.get('Rangeland', 0) or 0,0)
    response['barren_buildings_sand_covered_areas'] = round(temp.get('Sand Covered Areas', 0) or 0,0)
    response['barren_buildings_forest_shrub'] = round(temp.get('Forest & Shrub', 0) or 0,0)
    response['barren_buildings_sand_dunes'] = round(temp.get('Sand Dunes', 0) or 0,0)

    temp = dict([(c['agg_simplified_description'], c['areaatrisk']) for c in parent_data])
    response['built_up_area'] = round((temp.get('Build Up', 0) or 1)/1000000,1)
    response['cultivated_area'] = round((temp.get('Fruit Trees', 0) or 1)/1000000,1)+round((temp.get('Irrigated Agricultural Land', 0) or 1)/1000000,1)+round((temp.get('Rainfed', 0) or 1)/1000000,1)+round((temp.get('Vineyards', 0) or 1)/1000000,1)
    response['barren_area'] = round((temp.get('Water body and Marshland', 0) or 1)/1000000,1)+round((temp.get('Barren land', 0) or 1)/1000000,1)+round((temp.get('Snow', 0) or 1)/1000000,1)+round((temp.get('Rangeland', 0) or 1)/1000000,1)+round((temp.get('Sand Covered Areas', 0) or 1)/1000000,1)+round((temp.get('Forest & Shrub', 0) or 1)/1000000,1)+round((temp.get('Sand Dunes', 0) or 1)/1000000,1)

    response['built_up_area_build_up'] = round((temp.get('Build Up', 0) or 1)/1000000,1)
    response['cultivated_area_fruit_trees'] = round((temp.get('Fruit Trees', 0) or 1)/1000000,1)
    response['cultivated_area_irrigated_agricultural_land'] = round((temp.get('Irrigated Agricultural Land', 0) or 1)/1000000,1)
    response['cultivated_area_rainfed'] = round((temp.get('Rainfed', 0) or 1)/1000000,1)
    response['cultivated_area_vineyards'] = round((temp.get('Vineyards', 0) or 1)/1000000,1)
    response['barren_area_water_body_and_marshland'] = round((temp.get('Water body and Marshland', 0) or 1)/1000000,1)
    response['barren_area_barren_land'] = round((temp.get('Barren land', 0) or 1)/1000000,1)
    response['barren_area_snow'] = round((temp.get('Snow', 0) or 1)/1000000,1)
    response['barren_area_rangeland'] = round((temp.get('Rangeland', 0) or 1)/1000000,1)
    response['barren_area_sand_covered_areas'] = round((temp.get('Sand Covered Areas', 0) or 1)/1000000,1)
    response['barren_area_forest_shrub'] = round((temp.get('Forest & Shrub', 0) or 1)/1000000,1)
    response['barren_area_sand_dunes'] = round((temp.get('Sand Dunes', 0) or 1)/1000000,1)

    return response

def getQuickOverview(request, filterLock, flag, code, includes=[], excludes=[]):
    response = {}
    tempData = getShortCutData(flag,code)
    # response['Population']= tempData['Population']
    # response['Area']= tempData['Area']
    # response['Buildings']= tempData['total_buildings']
    # response['settlement']= tempData['settlements']
    if include_section('', includes, excludes):
        response.update(getBaseline(request, filterLock, flag, code, excludes=['getProvinceSummary', 'getProvinceAdditionalSummary'],
            inject={
                'forward':True,
                'Population': tempData['Population'],
                'Area': tempData['Area'],
                'total_buildings': tempData['total_buildings'],
                'settlements': tempData['settlements']
            }
        ))

        # add response from optional modules
        for modulename in settings.QUICKOVERVIEW_MODULES:
            module = importlib.import_module(modulename+'.views')
            response_add = module.getQuickOverview(request, filterLock, flag, code)
            response.update(response_add)
        
        # response.update(getFloodForecastMatrix(filterLock, flag, code, includes=['flashflood_forecast_risk_pop']))
        # response.update(getFloodForecast(request, filterLock, flag, code, excludes=['getCommonUse','detail']))
        # response.update(getRawFloodRisk(filterLock, flag, code, excludes=['landcoverfloodrisk']))
        # response.update(getRawAvalancheForecast(request, filterLock, flag, code))
        # response.update(getRawAvalancheRisk(filterLock, flag, code))
        # response.update(getLandslideRisk(request, filterLock, flag, code, includes=['lsi_immap']))
        # response.update(getEarthquake(request, filterLock, flag, code, excludes=['getListEQ']))

        # response.update(GetAccesibilityData(filterLock, flag, code, includes=['AfgCaptAirdrmImmap', 'AfgCaptHltfacTier1Immap', 'AfgCaptHltfacTier2Immap', 'AfgCaptAdm1ItsProvcImmap', 'AfgCapaGsmcvr']))
        # response['pop_coverage_percent'] = int(round((response['pop_on_gsm_coverage']/response['Population'])*100,0))

    # if include_section('getSAMParams', includes, excludes):
    #     rawFilterLock = filterLock if 'flag' in request.GET else None
    #     if 'daterange' in request.GET:
    #         daterange = request.GET.get('daterange')
    #     elif 'daterange' in request.POST:
    #         daterange = request.POST.get('daterange')
    #     else:
    #         enddate = datetime.date.today()
    #         startdate = datetime.date.today() - datetime.timedelta(days=365)
    #         daterange = startdate.strftime("%Y-%m-%d")+','+enddate.strftime("%Y-%m-%d")
    #     main_type_raw_data = getSAMParams(request, daterange, rawFilterLock, flag, code, group='main_type', includeFilter=True)
    #     response['incident_type'] = (i['main_type'] for i in main_type_raw_data)
    #     if 'incident_type' in request.GET:
    #         response['incident_type'] = request.GET['incident_type'].split(',')
    #     response['incident_type_group']=[]
    #     for i in main_type_raw_data:
    #         response['incident_type_group'].append({'count':i['count'],'injured':i['injured'],'violent':i['violent']+i['affected'],'dead':i['dead'],'main_type':i['main_type'],'child':list(getSAMIncident(request, daterange, rawFilterLock, flag, code, 'type', i['main_type']))})
    #     response['main_type_child'] = getSAMParams(request, daterange, rawFilterLock, flag, code, 'main_type', False)

    if include_section('GeoJson', includes, excludes):
        response['GeoJson'] = json.dumps(getGeoJson(request, flag, code))

    return response

def getShortCutData(flag, code):
    response = {}
    if flag=='entireAfg':
        px = provincesummary.objects.aggregate(Sum('high_ava_population'),Sum('med_ava_population'),Sum('low_ava_population'),Sum('total_ava_population'),Sum('high_ava_area'),Sum('med_ava_area'),Sum('low_ava_area'),Sum('total_ava_area'), \
            Sum('high_risk_population'),Sum('med_risk_population'),Sum('low_risk_population'),Sum('total_risk_population'), Sum('high_risk_area'),Sum('med_risk_area'),Sum('low_risk_area'),Sum('total_risk_area'),  \
            Sum('water_body_pop_risk'),Sum('barren_land_pop_risk'),Sum('built_up_pop_risk'),Sum('fruit_trees_pop_risk'),Sum('irrigated_agricultural_land_pop_risk'),Sum('permanent_snow_pop_risk'),Sum('rainfed_agricultural_land_pop_risk'),Sum('rangeland_pop_risk'),Sum('sandcover_pop_risk'),Sum('vineyards_pop_risk'),Sum('forest_pop_risk'), Sum('sand_dunes_pop_risk'), \
            Sum('water_body_area_risk'),Sum('barren_land_area_risk'),Sum('built_up_area_risk'),Sum('fruit_trees_area_risk'),Sum('irrigated_agricultural_land_area_risk'),Sum('permanent_snow_area_risk'),Sum('rainfed_agricultural_land_area_risk'),Sum('rangeland_area_risk'),Sum('sandcover_area_risk'),Sum('vineyards_area_risk'),Sum('forest_area_risk'), Sum('sand_dunes_area_risk'), \
            Sum('water_body_pop'),Sum('barren_land_pop'),Sum('built_up_pop'),Sum('fruit_trees_pop'),Sum('irrigated_agricultural_land_pop'),Sum('permanent_snow_pop'),Sum('rainfed_agricultural_land_pop'),Sum('rangeland_pop'),Sum('sandcover_pop'),Sum('vineyards_pop'),Sum('forest_pop'), Sum('sand_dunes_pop'), \
            Sum('water_body_area'),Sum('barren_land_area'),Sum('built_up_area'),Sum('fruit_trees_area'),Sum('irrigated_agricultural_land_area'),Sum('permanent_snow_area'),Sum('rainfed_agricultural_land_area'),Sum('rangeland_area'),Sum('sandcover_area'),Sum('vineyards_area'),Sum('forest_area'), Sum('sand_dunes_area'), \
            Sum('settlements_at_risk'), Sum('settlements'), Sum('Population'), Sum('Area'), Sum('ava_forecast_low_pop'), Sum('ava_forecast_med_pop'), Sum('ava_forecast_high_pop'), Sum('total_ava_forecast_pop'),
            Sum('total_buildings'), Sum('total_risk_buildings'), Sum('high_ava_buildings'), Sum('med_ava_buildings'), Sum('total_ava_buildings') )
    else:
        if len(str(code)) > 2:
            px = districtsummary.objects.filter(district=code).aggregate(Sum('high_ava_population'),Sum('med_ava_population'),Sum('low_ava_population'),Sum('total_ava_population'),Sum('high_ava_area'),Sum('med_ava_area'),Sum('low_ava_area'),Sum('total_ava_area'), \
                Sum('high_risk_population'),Sum('med_risk_population'),Sum('low_risk_population'),Sum('total_risk_population'), Sum('high_risk_area'),Sum('med_risk_area'),Sum('low_risk_area'),Sum('total_risk_area'),  \
                Sum('water_body_pop_risk'),Sum('barren_land_pop_risk'),Sum('built_up_pop_risk'),Sum('fruit_trees_pop_risk'),Sum('irrigated_agricultural_land_pop_risk'),Sum('permanent_snow_pop_risk'),Sum('rainfed_agricultural_land_pop_risk'),Sum('rangeland_pop_risk'),Sum('sandcover_pop_risk'),Sum('vineyards_pop_risk'),Sum('forest_pop_risk'), Sum('sand_dunes_pop_risk'), \
                Sum('water_body_area_risk'),Sum('barren_land_area_risk'),Sum('built_up_area_risk'),Sum('fruit_trees_area_risk'),Sum('irrigated_agricultural_land_area_risk'),Sum('permanent_snow_area_risk'),Sum('rainfed_agricultural_land_area_risk'),Sum('rangeland_area_risk'),Sum('sandcover_area_risk'),Sum('vineyards_area_risk'),Sum('forest_area_risk'), Sum('sand_dunes_area_risk'), \
                Sum('water_body_pop'),Sum('barren_land_pop'),Sum('built_up_pop'),Sum('fruit_trees_pop'),Sum('irrigated_agricultural_land_pop'),Sum('permanent_snow_pop'),Sum('rainfed_agricultural_land_pop'),Sum('rangeland_pop'),Sum('sandcover_pop'),Sum('vineyards_pop'),Sum('forest_pop'), Sum('sand_dunes_pop'), \
                Sum('water_body_area'),Sum('barren_land_area'),Sum('built_up_area'),Sum('fruit_trees_area'),Sum('irrigated_agricultural_land_area'),Sum('permanent_snow_area'),Sum('rainfed_agricultural_land_area'),Sum('rangeland_area'),Sum('sandcover_area'),Sum('vineyards_area'),Sum('forest_area'), Sum('sand_dunes_area'), \
                Sum('settlements_at_risk'), Sum('settlements'), Sum('Population'), Sum('Area'), Sum('ava_forecast_low_pop'), Sum('ava_forecast_med_pop'), Sum('ava_forecast_high_pop'), Sum('total_ava_forecast_pop'),
                Sum('total_buildings'), Sum('total_risk_buildings'), Sum('high_ava_buildings'), Sum('med_ava_buildings'), Sum('total_ava_buildings') )
        else :
            px = provincesummary.objects.filter(province=code).aggregate(Sum('high_ava_population'),Sum('med_ava_population'),Sum('low_ava_population'),Sum('total_ava_population'),Sum('high_ava_area'),Sum('med_ava_area'),Sum('low_ava_area'),Sum('total_ava_area'), \
                Sum('high_risk_population'),Sum('med_risk_population'),Sum('low_risk_population'),Sum('total_risk_population'), Sum('high_risk_area'),Sum('med_risk_area'),Sum('low_risk_area'),Sum('total_risk_area'),  \
                Sum('water_body_pop_risk'),Sum('barren_land_pop_risk'),Sum('built_up_pop_risk'),Sum('fruit_trees_pop_risk'),Sum('irrigated_agricultural_land_pop_risk'),Sum('permanent_snow_pop_risk'),Sum('rainfed_agricultural_land_pop_risk'),Sum('rangeland_pop_risk'),Sum('sandcover_pop_risk'),Sum('vineyards_pop_risk'),Sum('forest_pop_risk'), Sum('sand_dunes_pop_risk'), \
                Sum('water_body_area_risk'),Sum('barren_land_area_risk'),Sum('built_up_area_risk'),Sum('fruit_trees_area_risk'),Sum('irrigated_agricultural_land_area_risk'),Sum('permanent_snow_area_risk'),Sum('rainfed_agricultural_land_area_risk'),Sum('rangeland_area_risk'),Sum('sandcover_area_risk'),Sum('vineyards_area_risk'),Sum('forest_area_risk'), Sum('sand_dunes_area_risk'), \
                Sum('water_body_pop'),Sum('barren_land_pop'),Sum('built_up_pop'),Sum('fruit_trees_pop'),Sum('irrigated_agricultural_land_pop'),Sum('permanent_snow_pop'),Sum('rainfed_agricultural_land_pop'),Sum('rangeland_pop'),Sum('sandcover_pop'),Sum('vineyards_pop'),Sum('forest_pop'), Sum('sand_dunes_pop'), \
                Sum('water_body_area'),Sum('barren_land_area'),Sum('built_up_area'),Sum('fruit_trees_area'),Sum('irrigated_agricultural_land_area'),Sum('permanent_snow_area'),Sum('rainfed_agricultural_land_area'),Sum('rangeland_area'),Sum('sandcover_area'),Sum('vineyards_area'),Sum('forest_area'), Sum('sand_dunes_area'), \
                Sum('settlements_at_risk'), Sum('settlements'), Sum('Population'), Sum('Area'), Sum('ava_forecast_low_pop'), Sum('ava_forecast_med_pop'), Sum('ava_forecast_high_pop'), Sum('total_ava_forecast_pop'),
                Sum('total_buildings'), Sum('total_risk_buildings'), Sum('high_ava_buildings'), Sum('med_ava_buildings'), Sum('total_ava_buildings') )

    for p in px:
        response[p[:-5]] = px[p]
    return response

def getBaseline(request, filterLock, flag, code, includes=[], excludes=[], inject={'forward':False}):
    response = getCommonUse(request, flag, code)
    targetBase = AfgLndcrva.objects.all()

    if flag not in ['entireAfg','currentProvince']:
        response['Population']=getTotalPop(filterLock, flag, code, targetBase)
        response['Area']=getTotalArea(filterLock, flag, code, targetBase)
        response['Buildings']=getTotalBuildings(filterLock, flag, code, targetBase)
        response['settlement']=getTotalSettlement(filterLock, flag, code, targetBase)
    else :
        if inject['forward']:
            response['Population']= inject['Population']
            response['Area']= inject['Area']
            response['Buildings']= inject['total_buildings']
            response['settlement']= inject['settlements']
        else:
            tempData = getShortCutData(flag,code)
            response['Population']= tempData['Population']
            response['Area']= tempData['Area']
            response['Buildings']= tempData['total_buildings']
            response['settlement']= tempData['settlements']

    response['hltfac']=getTotalHealthFacilities(filterLock, flag, code, AfgHltfac)
    response['roadnetwork']=getTotalRoadNetwork(filterLock, flag, code, AfgRdsl)
    if response['roadnetwork']==0:
        response['roadnetwork'] = 0.00000000001

    rawBaseline = getRawBaseLine(filterLock, flag, code)
    for i in rawBaseline:
        response[i]=rawBaseline[i]

    hltParentData = getParentHltFacRecap(filterLock, flag, code)
    tempHLTBase = dict([(c['facility_types_description'], c['numberhospital']) for c in hltParentData])
    response['hlt_h1'] = round(tempHLTBase.get("Regional / National Hospital (H1)", 0))
    response['hlt_h2'] = round(tempHLTBase.get("Provincial Hospital (H2)", 0))
    response['hlt_h3'] = round(tempHLTBase.get("District Hospital (H3)", 0))
    response['hlt_chc'] = round(tempHLTBase.get("Comprehensive Health Center (CHC)", 0))
    response['hlt_bhc'] = round(tempHLTBase.get("Basic Health Center (BHC)", 0))
    response['hlt_shc'] = round(tempHLTBase.get("Sub Health Center (SHC)", 0))
    response['hlt_others'] = round(tempHLTBase.get("Rehabilitation Center (RH)", 0))+round(tempHLTBase.get("Special Hospital (SH)", 0))+round(tempHLTBase.get("Maternity Home (MH)", 0))+round(tempHLTBase.get("Drug Addicted Treatment Center", 0))+round(tempHLTBase.get("Private Clinic", 0))+round(tempHLTBase.get("Other", 0))+round(tempHLTBase.get("Malaria Center (MC)", 0))+round(tempHLTBase.get("Mobile Health Team (MHT)", 0))

    roadParentData = getParentRoadNetworkRecap(filterLock, flag, code)
    tempRoadBase = dict([(c['type_update'], c['road_length']) for c in roadParentData])
    response['road_primary'] = round(tempRoadBase.get("primary", 0))
    response['road_secondary'] = round(tempRoadBase.get("secondary", 0))
    response['road_track'] = round(tempRoadBase.get("track", 0))
    response['road_tertiary'] = round(tempRoadBase.get("tertiary", 0))
    response['road_path'] = round(tempRoadBase.get("path", 0))
    response['road_highway'] = round(tempRoadBase.get("highway", 0))
    response['road_residential'] = round(tempRoadBase.get("residential", 0))
    response['road_river_crossing'] = round(tempRoadBase.get("river crossing", 0))
    response['road_bridge'] = round(tempRoadBase.get("bridge", 0))

    if include_section('getProvinceSummary', includes, excludes):
        data = getProvinceSummary(filterLock, flag, code)
        response['lc_child']=data

    if include_section('getProvinceAdditionalSummary', includes, excludes):
        data = getProvinceAdditionalSummary(filterLock, flag, code)
        response['additional_child']=data

    dataLC = []
    dataLC.append([_('landcover type'),_('population'), { 'role': 'annotation' },_('buildings'), { 'role': 'annotation' },_('area (km2)'), { 'role': 'annotation' }])
    # dataLC.append([_('Built-up'),round((response['built_up_pop'] or 0)/(response['Population'] or 0)*100,0), response['built_up_pop'],round((response['built_up_buildings'] or 0)/(response['Buildings'] or 0)*100,0), response['built_up_buildings'], round((response['built_up_area'] or 0)/(response['Area'] or 0)*100,0), response['built_up_area'] ])
    # dataLC.append([_('Cultivated'),round((response['cultivated_pop'] or 0)/(response['Population'] or 0)*100,0), response['cultivated_pop'],round((response['cultivated_buildings'] or 0)/(response['Buildings'] or 0)*100,0), response['cultivated_buildings'], round((response['cultivated_area'] or 0)/(response['Area']*100 or 0),0), response['cultivated_area'] ])
    # dataLC.append([_('Barren/Rangeland'),round((response['barren_pop'] or 0)/(response['Population'] or 0)*100,0), response['barren_pop'],round((response['barren_buildings'] or 0)/(response['Buildings'] or 0)*100,0), response['barren_buildings'], round((response['barren_area'] or 0)/(response['Area'] or 0)*100,0), response['barren_area'] ])
    response['landcover_chart'] = gchart.BarChart(
        SimpleDataSource(data=dataLC),
        html_id="pie_chart1",
        options={
            'title': _('Landcover Population and area overview'),
            # 'subtitle': 'figure as percent from total population and area',
            'width': 450,
            'height': 300,
            # 'legend': { 'position': 'none' },
            # 'chart': { 'title': 'Landcover Population and area overview', 'subtitle': 'figure as percent from total population and area' },
            'bars': 'horizontal',
            'axes': {
                'x': {
                  '0': { 'side': 'top', 'label': _('Percentage')}
                },

            },
            'bar': { 'groupWidth': '90%' },
            'chartArea': {'width': '50%'},
            'titleX':_('percentages from total population, buildings & area'),
    })
    if response['hltfac']==0:
        response['hltfac'] = 0.000001

    dataHLT = []
    dataHLT.append([_('health facility type'),_('percent of health facility'), { 'role': 'annotation' }])
    dataHLT.append([_('H1'),round(response['hlt_h1']/response['hltfac']*100,0), response['hlt_h1'] ])
    dataHLT.append([_('H2'),round(response['hlt_h2']/response['hltfac']*100,0), response['hlt_h2'] ])
    dataHLT.append([_('H3'),round(response['hlt_h3']/response['hltfac']*100,0), response['hlt_h3'] ])
    dataHLT.append([_('CHC'),round(response['hlt_chc']/response['hltfac']*100,0), response['hlt_chc'] ])
    dataHLT.append([_('BHC'),round(response['hlt_bhc']/response['hltfac']*100,0), response['hlt_bhc'] ])
    dataHLT.append([_('SHC'),round(response['hlt_shc']/response['hltfac']*100,0), response['hlt_shc'] ])
    dataHLT.append([_('Others'),round(response['hlt_others']/response['hltfac']*100,0), response['hlt_others'] ])
    response['hlt_chart'] = gchart.BarChart(
        SimpleDataSource(data=dataHLT),
        html_id="pie_chart2",
        options={
            'title': _('Health facilities overview'),
            # 'subtitle': 'figure as percent from total population and area',
            'width': 450,
            'height': 300,
            'legend': { 'position': 'none' },
            # 'chart': { 'title': 'Landcover Population and area overview', 'subtitle': 'figure as percent from total population and area' },
            'bars': 'horizontal',
            'axes': {
                'x': {
                  '0': { 'side': 'top', 'label': _('Percentage')}
                },

            },
            'bar': { 'groupWidth': '90%' },
            'chartArea': {'width': '50%'},
            'titleX':_('percentages from total health facilities'),
    })

    dataRDN = []
    dataRDN.append([_('road network type'),_('percent of road network'), { 'role': 'annotation' }])
    dataRDN.append([_('Highway'),round(response['road_highway']/response['roadnetwork']*100,0), response['road_highway'] ])
    dataRDN.append([_('Primary'),round(response['road_primary']/response['roadnetwork']*100,0), response['road_primary'] ])
    dataRDN.append([_('Secondary'),round(response['road_secondary']/response['roadnetwork']*100,0), response['road_secondary'] ])
    dataRDN.append([_('Tertiary'),round(response['road_tertiary']/response['roadnetwork']*100,0), response['road_tertiary'] ])
    dataRDN.append([_('Residential'),round(response['road_residential']/response['roadnetwork']*100,0), response['road_residential'] ])
    dataRDN.append([_('Track'),round(response['road_track']/response['roadnetwork']*100,0), response['road_track'] ])
    dataRDN.append([_('Path'),round(response['road_path']/response['roadnetwork']*100,0), response['road_path'] ])
    dataRDN.append([_('River crossing'),round(response['road_river_crossing']/response['roadnetwork']*100,0), response['road_river_crossing'] ])
    dataRDN.append([_('Bridge'),round(response['road_bridge']/response['roadnetwork']*100,0), response['road_bridge'] ])
    response['rdn_chart'] = gchart.BarChart(
        SimpleDataSource(data=dataRDN),
        options={
            'title': _('Road network overview'),
            # 'subtitle': 'figure as percent from total population and area',
            'width': 450,
            'height': 300,
            'legend': { 'position': 'none' },
            # 'chart': { 'title': 'Landcover Population and area overview', 'subtitle': 'figure as percent from total population and area' },
            'bars': 'horizontal',
            'axes': {
                'x': {
                  '0': { 'side': 'top', 'label': _('Percentage')}
                },

            },
            'bar': { 'groupWidth': '90%' },
            'chartArea': {'width': '50%'},
            'titleX':_('percentages from total length of road network'),
    })

    # print response['poi_points']
    # print response['additional_child']
    # for i in response['additional_child']:
    #     test = [item for item in response['poi_points'] if item['code'] == i['code']][0]
    #     i['x'] = test['x']
    #     i['y'] = test['y']

    # response['additional_child'] = json.dumps(response['additional_child'])
    # print response['additional_child']

    # if include_section('GeoJson', includes, excludes):
    #     response['GeoJson'] = json.dumps(getGeoJson(request, flag, code))
        # response['GeoJson'] = getGeoJson(request, flag, code)

    #print 'It took', time.time()-start, 'seconds.'

    return response

def getParentRoadNetworkRecap(filterLock, flag, code):
    if flag=='drawArea':
        # countsRoadBase = AfgRdsl.objects.all().values('type_update').annotate(counter=Count('ogc_fid')).extra(
        # select={
        #     'road_length' : 'SUM(  \
        #             case \
        #                 when ST_CoveredBy(wkb_geometry'+','+filterLock+') then road_length \
        #                 else ST_Length(st_intersection(wkb_geometry::geography'+','+filterLock+')) / road_length end \
        #         )/1000'
        # },
        # where = {
        #     'ST_Intersects(wkb_geometry'+', '+filterLock+')'
        # }).values('type_update','road_length')
        countsRoadBase = AfgRdsl.objects.all().values('type_update').\
            annotate(counter=Count('ogc_fid')).\
            annotate(road_length=RawSQL_nogroupby('SUM(  \
                    case \
                            when ST_CoveredBy(wkb_geometry'+','+filterLock+') then road_length \
                            else ST_Length(st_intersection(wkb_geometry::geography'+','+filterLock+')) / road_length end \
                    )/1000', ())).\
            extra(
                where = {
                    'ST_Intersects(wkb_geometry'+', '+filterLock+')'
                })

    elif flag=='entireAfg':
        # countsRoadBase = AfgRdsl.objects.all().values('type_update').annotate(counter=Count('ogc_fid')).extra(
        #         select={
        #             'road_length' : 'SUM(road_length)/1000'
        #         }).values('type_update', 'road_length')
        print AfgRdsl.objects.all().values('type_update').\
            annotate(counter=Count('ogc_fid')).\
            annotate(road_length=RawSQL_nogroupby('SUM("road_length")',())/1000).query
        countsRoadBase = AfgRdsl.objects.all().values('type_update').\
            annotate(counter=Count('ogc_fid')).\
            annotate(road_length=Sum('road_length')/1000)

    elif flag=='currentProvince':
        if len(str(code)) > 2:
            ff0001 =  "dist_code  = '"+str(code)+"'"
        else :
            if len(str(code))==1:
                ff0001 =  "left(cast(dist_code as text),1)  = '"+str(code)+"' and length(cast(dist_code as text))=3"
            else:
                ff0001 =  "left(cast(dist_code as text),2)  = '"+str(code)+"' and length(cast(dist_code as text))=4"

        countsRoadBase = AfgRdsl.objects.all().values('type_update').annotate(counter=Count('ogc_fid')).extra(
            select={
                 'road_length' : 'SUM(road_length)/1000'
            },
            where = {
                ff0001
             }).values('type_update','road_length')

    elif flag=='currentBasin':
        print 'currentBasin'
    else:
        countsRoadBase = AfgRdsl.objects.all().values('type_update').annotate(counter=Count('ogc_fid')).extra(
            select={
                'road_length' : 'SUM(road_length)/1000'
            },
            where = {
                'ST_Within(wkb_geometry'+', '+filterLock+')'
            }).values('type_update','road_length')
    return countsRoadBase

def getParentHltFacRecap(filterLock, flag, code):
    targetBase = AfgHltfac.objects.all().filter(activestatus='Y')
    if flag=='drawArea':
        countsHLTBase = targetBase.values('facility_types_description').annotate(counter=Count('ogc_fid')).extra(
                select={
                    'numberhospital' : 'count(*)'
                },
                where = {
                    'ST_Intersects(wkb_geometry'+', '+filterLock+')'
                }).values('facility_types_description','numberhospital')

    elif flag=='entireAfg':
        # countsHLTBase = targetBase.values('facility_types_description').annotate(counter=Count('ogc_fid')).extra(
        #         select={
        #             'numberhospital' : 'count(*)'
        #         }).values('facility_types_description','numberhospital')
        # isdc rewrite
        countsHLTBase = targetBase.values('facility_types_description').\
            annotate(counter=Count('ogc_fid')).\
            annotate(numberhospital=Count('ogc_fid'))

    elif flag=='currentProvince':
        if len(str(code)) > 2:
            ff0001 =  "dist_code  = '"+str(code)+"'"
        else :
            ff0001 = "prov_code  = '"+str(code)+"'"

        countsHLTBase = targetBase.values('facility_types_description').annotate(counter=Count('ogc_fid')).extra(
            select={
                    'numberhospital' : 'count(*)'
            },where = {
                ff0001
            }).values('facility_types_description','numberhospital')
    elif flag=='currentBasin':
        print 'currentBasin'
    else:
        countsHLTBase = targetBase.values('facility_types_description').annotate(counter=Count('ogc_fid')).extra(
            select={
                    'numberhospital' : 'count(*)'
            },where = {
                'ST_Within(wkb_geometry'+', '+filterLock+')'
            }).values('facility_types_description','numberhospital')
    return countsHLTBase

def getTotalBuildings(filterLock, flag, code, targetBase):
    # All population number
    if flag=='drawArea':
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(  \
                        case \
                            when ST_CoveredBy(wkb_geometry,'+filterLock+') then area_buildings \
                            else st_area(st_intersection(wkb_geometry,'+filterLock+')) / st_area(wkb_geometry)*area_buildings end \
                    )'
            },
            where = {
                'ST_Intersects(wkb_geometry, '+filterLock+')'
            }).values('countbase')
    elif flag=='entireAfg':
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(area_buildings)'
            }).values('countbase')
    elif flag=='currentProvince':
        if len(str(code)) > 2:
            ff0001 =  "dist_code  = '"+str(code)+"'"
        else :
            ff0001 =  "prov_code  = '"+str(code)+"'"
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(area_buildings)'
            },
            where = {
                ff0001
            }).values('countbase')
    elif flag=='currentBasin':
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(area_buildings)'
            },
            where = {"vuid = '"+str(code)+"'"}).values('countbase')
    else:
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(area_buildings)'
            },
            where = {
                'ST_Within(wkb_geometry, '+filterLock+')'
            }).values('countbase')

    return round(countsBase[0]['countbase'] or 0,0)

def getTotalPop(filterLock, flag, code, targetBase):
    # All population number
    if flag=='drawArea':
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(  \
                        case \
                            when ST_CoveredBy(wkb_geometry,'+filterLock+') then area_population \
                            else st_area(st_intersection(wkb_geometry,'+filterLock+')) / st_area(wkb_geometry)*area_population end \
                    )'
            },
            where = {
                'ST_Intersects(wkb_geometry, '+filterLock+')'
            }).values('countbase')
    elif flag=='entireAfg':
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(area_population)'
            }).values('countbase')
    elif flag=='currentProvince':
        if len(str(code)) > 2:
            ff0001 =  "dist_code  = '"+str(code)+"'"
        else :
            ff0001 =  "prov_code  = '"+str(code)+"'"
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(area_population)'
            },
            where = {
                ff0001
            }).values('countbase')
    elif flag=='currentBasin':
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(area_population)'
            },
            where = {"vuid = '"+str(code)+"'"}).values('countbase')
    else:
        countsBase = targetBase.extra(
            select={
                'countbase' : 'SUM(area_population)'
            },
            where = {
                'ST_Within(wkb_geometry, '+filterLock+')'
            }).values('countbase')

    return round(countsBase[0]['countbase'] or 0,0)

def getTotalArea(filterLock, flag, code, targetBase):
    if flag=='drawArea':
        countsBase = targetBase.extra(
            select={
                'areabase' : 'SUM(  \
                        case \
                            when ST_CoveredBy(wkb_geometry,'+filterLock+') then area_sqm \
                            else st_area(st_intersection(wkb_geometry,'+filterLock+')) / st_area(wkb_geometry)*area_sqm end \
                    )'
            },
            where = {
                'ST_Intersects(wkb_geometry, '+filterLock+')'
            }).values('areabase')
    elif flag=='entireAfg':
        countsBase = targetBase.extra(
            select={
                'areabase' : 'SUM(area_sqm)'
            }).values('areabase')
    elif flag=='currentProvince':
        if len(str(code)) > 2:
            ff0001 =  "dist_code  = '"+str(code)+"'"
        else :
            ff0001 =  "prov_code  = '"+str(code)+"'"
        countsBase = targetBase.extra(
            select={
                'areabase' : 'SUM(area_sqm)'
            },
            where = {
                ff0001
            }).values('areabase')
    elif flag=='currentBasin':
        countsBase = targetBase.extra(
            select={
                'areabase' : 'SUM(area_sqm)'
            },
            where = {"vuid = '"+str(code)+"'"}).values('areabase')

    else:
        countsBase = targetBase.extra(
            select={
                'areabase' : 'SUM(area_sqm)'
            },
            where = {
                'ST_Within(wkb_geometry, '+filterLock+')'
            }).values('areabase')

    return round((countsBase[0]['areabase'] or 0)/1000000,0)

def getTotalSettlement(filterLock, flag, code, targetBase):
    if flag=='drawArea':
        countsBase = targetBase.exclude(agg_simplified_description='Water body and Marshland').extra(
            select={
                'numbersettlements': 'count(distinct vuid)'},
            where = {'st_area(st_intersection(wkb_geometry,'+filterLock+')) / st_area(wkb_geometry)*area_sqm > 1 and ST_Intersects(wkb_geometry, '+filterLock+')'}).values('numbersettlements')
    elif flag=='entireAfg':
        countsBase = targetBase.exclude(agg_simplified_description='Water body and Marshland').extra(
            select={
                'numbersettlements': 'count(distinct vuid)'}).values('numbersettlements')
    elif flag=='currentProvince':
        if len(str(code)) > 2:
            ff0001 =  "dist_code  = '"+str(code)+"'"
        else :
            ff0001 =  "prov_code  = '"+str(code)+"'"
        countsBase = targetBase.exclude(agg_simplified_description='Water body and Marshland').extra(
            select={
                'numbersettlements': 'count(distinct vuid)'},
            where = {ff0001}).values('numbersettlements')
    elif flag=='currentBasin':
        countsBase = targetBase.exclude(agg_simplified_description='Water body and Marshland').extra(
            select={
                'numbersettlements': 'count(distinct vuid)'},
            where = {"vuid = '"+str(code)+"'"}).values('numbersettlements')
    else:
        countsBase = targetBase.exclude(agg_simplified_description='Water body and Marshland').extra(
            select={
                'numbersettlements': 'count(distinct vuid)'},
            where = {'ST_Within(wkb_geometry, '+filterLock+')'}).values('numbersettlements')

    return round(countsBase[0]['numbersettlements'],0)

def getTotalHealthFacilities(filterLock, flag, code, targetBase):
    # targetBase = targetBase.objects.all().filter(activestatus='Y').values('facility_types_description')
    targetBase = targetBase.objects.all().filter(activestatus='Y')
    if flag=='drawArea':
        countsHLTBase = targetBase.extra(
                select={
                    'numberhospital' : 'count(*)'
                },
                where = {
                    'ST_Intersects(wkb_geometry'+', '+filterLock+')'
                }).values('numberhospital')

    elif flag=='entireAfg':
        countsHLTBase = targetBase.extra(
                select={
                    'numberhospital' : 'count(*)'
                }).values('numberhospital')

    elif flag=='currentProvince':
        if len(str(code)) > 2:
            ff0001 =  "dist_code  = '"+str(code)+"'"
        else :
            ff0001 = "prov_code  = '"+str(code)+"'"

        countsHLTBase = targetBase.extra(
            select={
                    'numberhospital' : 'count(*)'
            },where = {
                ff0001
            }).values('numberhospital')
    elif flag=='currentBasin':
        print 'currentBasin'
    else:
        countsHLTBase = targetBase.extra(
            select={
                    'numberhospital' : 'count(*)'
            },where = {
                'ST_Within(wkb_geometry'+', '+filterLock+')'
            }).values('numberhospital')
    return round(countsHLTBase[0]['numberhospital'],0)

def getTotalRoadNetwork(filterLock, flag, code, targetBase):
    # targetBase = targetBase.objects.all().filter(activestatus='Y').values('facility_types_description')
    if flag=='drawArea':
        countsRoadBase = targetBase.objects.all().extra(
        select={
            'road_length' : 'SUM(  \
                    case \
                        when ST_CoveredBy(wkb_geometry'+','+filterLock+') then road_length \
                        else ST_Length(st_intersection(wkb_geometry::geography'+','+filterLock+')) / road_length end \
                )/1000'
        },
        where = {
            'ST_Intersects(wkb_geometry'+', '+filterLock+')'
        }).values('road_length')

    elif flag=='entireAfg':
        countsRoadBase = targetBase.objects.all().extra(
                select={
                    'road_length' : 'SUM(road_length)/1000'
                }).values('road_length')

    elif flag=='currentProvince':
        if len(str(code)) > 2:
            ff0001 =  "dist_code  = '"+str(code)+"'"
        else :
            if len(str(code))==1:
                ff0001 =  "left(cast(dist_code as text),1)  = '"+str(code)+"'  and length(cast(dist_code as text))=3"
            else:
                ff0001 =  "left(cast(dist_code as text),2)  = '"+str(code)+"'  and length(cast(dist_code as text))=4"

        countsRoadBase = targetBase.objects.all().extra(
            select={
                 'road_length' : 'SUM(road_length)/1000'
            },
            where = {
                ff0001
             }).values('road_length')

    elif flag=='currentBasin':
        print 'currentBasin'
    else:
        countsRoadBase = targetBase.objects.all().extra(
            select={
                'road_length' : 'SUM(road_length)/1000'
            },
            where = {
                'ST_Within(wkb_geometry'+', '+filterLock+')'
            }).values('road_length')
    return round(float(countsRoadBase[0]['road_length'] or 0),0)

def getProvinceSummary(filterLock, flag, code):
    cursor = connections['geodb'].cursor()

    print flag, code

    if flag == 'entireAfg':
        sql = "select b.prov_code as code, b.prov_na_en as na_en, a.*, \
            a.fruit_trees_pop+a.irrigated_agricultural_land_pop+a.rainfed_agricultural_land_pop+a.vineyards_pop as cultivated_pop,  \
            a.fruit_trees_area+a.irrigated_agricultural_land_area+a.rainfed_agricultural_land_area+a.vineyards_area as cultivated_area,  \
            a.water_body_pop+a.barren_land_pop+a.permanent_snow_pop+a.rangeland_pop+a.sandcover_pop+a.forest_pop+a.sand_dunes_pop as barren_pop,  \
            a.water_body_area+a.barren_land_area+a.permanent_snow_area+a.rangeland_area+a.sandcover_area+a.forest_area+a.sand_dunes_area as barren_area,  \
             \
            a.fruit_trees_pop_risk+a.irrigated_agricultural_land_pop_risk+a.rainfed_agricultural_land_pop_risk+a.vineyards_pop_risk as cultivated_pop_risk, \
            a.fruit_trees_area_risk+a.irrigated_agricultural_land_area_risk+a.rainfed_agricultural_land_area_risk+a.vineyards_area_risk as cultivated_area_risk, \
            a.barren_land_pop_risk+a.permanent_snow_pop_risk+a.rangeland_pop_risk+a.sandcover_pop_risk+a.forest_pop_risk+a.sand_dunes_pop_risk as barren_pop_risk, \
            a.barren_land_area_risk+a.permanent_snow_area_risk+a.rangeland_area_risk+a.sandcover_area_risk+a.forest_area_risk+a.sand_dunes_area_risk as barren_area_risk \
            from provincesummary a \
            inner join afg_admbnda_adm1 b on cast(a.province as integer)=b.prov_code \
            order by a.\"Population\" desc"
    elif flag == 'currentProvince':
        sql = "select b.dist_code as code, b.dist_na_en as na_en, a.*, \
            a.fruit_trees_pop+a.irrigated_agricultural_land_pop+a.rainfed_agricultural_land_pop+a.vineyards_pop as cultivated_pop,  \
            a.fruit_trees_area+a.irrigated_agricultural_land_area+a.rainfed_agricultural_land_area+a.vineyards_area as cultivated_area,  \
            a.water_body_pop+a.barren_land_pop+a.permanent_snow_pop+a.rangeland_pop+a.sandcover_pop+a.forest_pop+a.sand_dunes_pop as barren_pop,  \
            a.water_body_area+a.barren_land_area+a.permanent_snow_area+a.rangeland_area+a.sandcover_area+a.forest_area+a.sand_dunes_area as barren_area,  \
             \
            a.fruit_trees_pop_risk+a.irrigated_agricultural_land_pop_risk+a.rainfed_agricultural_land_pop_risk+a.vineyards_pop_risk as cultivated_pop_risk, \
            a.fruit_trees_area_risk+a.irrigated_agricultural_land_area_risk+a.rainfed_agricultural_land_area_risk+a.vineyards_area_risk as cultivated_area_risk, \
            a.barren_land_pop_risk+a.permanent_snow_pop_risk+a.rangeland_pop_risk+a.sandcover_pop_risk+a.forest_pop_risk+a.sand_dunes_pop_risk as barren_pop_risk, \
            a.barren_land_area_risk+a.permanent_snow_area_risk+a.rangeland_area_risk+a.sandcover_area_risk+a.forest_area_risk+a.sand_dunes_area_risk as barren_area_risk \
            from districtsummary a \
            inner join afg_admbnda_adm2 b on cast(a.district as integer)=b.dist_code \
            where b.prov_code="+str(code)+" \
            order by a.\"Population\" desc"
    else:
        return []

    row = query_to_dicts(cursor, sql)

    response = []

    for i in row:
        response.append(i)

    cursor.close()

    return response

def getProvinceAdditionalSummary(filterLock, flag, code):
    cursor = connections['geodb'].cursor()

    if flag == 'entireAfg':
        sql = "select b.prov_code as code, b.prov_na_en as na_en, a.*, \
        a.hlt_special_hospital+a.hlt_rehabilitation_center+a.hlt_maternity_home+a.hlt_drug_addicted_treatment_center+a.hlt_private_clinic+a.hlt_malaria_center+a.hlt_mobile_health_team+a.hlt_other as hlt_others, \
        a.hlt_special_hospital+a.hlt_rehabilitation_center+a.hlt_maternity_home+a.hlt_drug_addicted_treatment_center+a.hlt_private_clinic+a.hlt_malaria_center+a.hlt_mobile_health_team+a.hlt_other+a.hlt_h1+a.hlt_h2+a.hlt_h3+a.hlt_chc+a.hlt_bhc+a.hlt_shc as hlt_total, \
        a.road_highway+a.road_primary+a.road_secondary+a.road_tertiary+a.road_residential+a.road_track+a.road_path+a.road_river_crossing+a.road_bridge as road_total \
        from province_add_summary a \
        inner join afg_admbnda_adm1 b on cast(a.prov_code as integer)=b.prov_code"
    elif flag == 'currentProvince':
        sql = "select b.dist_code as code, b.dist_na_en as na_en, a.*, \
        a.hlt_special_hospital+a.hlt_rehabilitation_center+a.hlt_maternity_home+a.hlt_drug_addicted_treatment_center+a.hlt_private_clinic+a.hlt_malaria_center+a.hlt_mobile_health_team+a.hlt_other as hlt_others, \
        a.hlt_special_hospital+a.hlt_rehabilitation_center+a.hlt_maternity_home+a.hlt_drug_addicted_treatment_center+a.hlt_private_clinic+a.hlt_malaria_center+a.hlt_mobile_health_team+a.hlt_other+a.hlt_h1+a.hlt_h2+a.hlt_h3+a.hlt_chc+a.hlt_bhc+a.hlt_shc as hlt_total, \
        a.road_highway+a.road_primary+a.road_secondary+a.road_tertiary+a.road_residential+a.road_track+a.road_path+a.road_river_crossing+a.road_bridge as road_total \
        from district_add_summary a \
        inner join afg_admbnda_adm2 b on cast(a.dist_code as integer)=b.dist_code \
        where b.prov_code="+str(code)
    else:
        return []

    row = query_to_dicts(cursor, sql)

    response = []

    for i in row:
        response.append(i)

    cursor.close()

    return response

def getProvinceSummary_glofas(filterLock, flag, code, YEAR, MONTH, DAY, merge):
    cursor = connections['geodb'].cursor()
    table = 'get_glofas_detail'
    if merge:
        table = 'get_merge_glofas_gfms_detail'

    if flag == 'entireAfg':
        sql = "select b.prov_code as code, b.prov_na_en as na_en, \
                a.flashflood_forecast_extreme_pop, \
                a.flashflood_forecast_veryhigh_pop, \
                a.flashflood_forecast_high_pop, \
                a.flashflood_forecast_med_pop, \
                a.flashflood_forecast_low_pop, \
                a.flashflood_forecast_verylow_pop, \
                a.riverflood_forecast_extreme_pop, \
                a.riverflood_forecast_veryhigh_pop, \
                a.riverflood_forecast_high_pop, \
                a.riverflood_forecast_med_pop, \
                a.riverflood_forecast_low_pop, \
                a.riverflood_forecast_verylow_pop, \
                c.extreme, \
                c.veryhigh, \
                c.high, \
                c.moderate, \
                c.low, \
                c.verylow \
                from afg_admbnda_adm1 b \
                left join provincesummary a  on cast(a.province as integer)=b.prov_code \
                left join (\
                select \
                prov_code,\
                sum(extreme) as extreme,\
                sum(veryhigh) as veryhigh,\
                sum(high) as high, \
                sum(moderate) as moderate, \
                sum(low) as low, \
                sum(verylow) as verylow \
                from %s('%s-%s-%s') \
                group by prov_code \
                ) c on b.prov_code = c.prov_code \
                order by a.\"Population\" desc" %(table,YEAR,MONTH,DAY)
    elif flag == 'currentProvince':
        sql = "select b.dist_code as code, b.dist_na_en as na_en, \
                a.flashflood_forecast_extreme_pop, \
                a.flashflood_forecast_veryhigh_pop, \
                a.flashflood_forecast_high_pop, \
                a.flashflood_forecast_med_pop, \
                a.flashflood_forecast_low_pop, \
                a.flashflood_forecast_verylow_pop, \
                a.riverflood_forecast_extreme_pop, \
                a.riverflood_forecast_veryhigh_pop, \
                a.riverflood_forecast_high_pop, \
                a.riverflood_forecast_med_pop, \
                a.riverflood_forecast_low_pop, \
                a.riverflood_forecast_verylow_pop, \
                c.extreme, \
                c.veryhigh, \
                c.high, \
                c.moderate, \
                c.low, \
                c.verylow \
                from afg_admbnda_adm2 b \
                left join districtsummary a  on cast(a.district as integer)=b.dist_code \
                left join (\
                select \
                dist_code,\
                sum(extreme) as extreme,\
                sum(veryhigh) as veryhigh,\
                sum(high) as high, \
                sum(moderate) as moderate, \
                sum(low) as low, \
                sum(verylow) as verylow \
                from %s('%s-%s-%s') \
                group by dist_code \
                ) c on b.dist_code = c.dist_code \
                where b.prov_code=%s \
                order by a.\"Population\" desc" %(table,YEAR,MONTH,DAY,code)

    else:
        return []

    row = query_to_dicts(cursor, sql)

    response = []

    for i in row:
        response.append(i)

    cursor.close()

    return response

def getGeoJson (filterLock, flag, code):
    if flag=='drawArea':
        # getprov = AfgAdmbndaAdm1.objects.all().values('type_update').annotate(counter=Count('ogc_fid')).extra(
        # select={
        #     'road_length' : 'SUM(  \
        #             case \
        #                 when ST_CoveredBy(wkb_geometry'+','+filterLock+') then road_length \
        #                 else ST_Length(st_intersection(wkb_geometry::geography'+','+filterLock+')) / road_length end \
        #         )/1000'
        # },
        # where = {
        #     'ST_Intersects(wkb_geometry'+', '+filterLock+')'
        # }).values('type_update','road_length')
        getprov = AfgAdmbndaAdm1.objects.all().extra(select={'code': 'prov_code', 'centroid': 'ST_AsText(wkb_geometry)'})
    elif flag=='entireAfg':
        getprov = AfgAdmbndaAdm1.objects.all().extra(select={'code': 'prov_code', 'centroid': 'ST_AsText(wkb_geometry)'})
    elif flag=='currentProvince':
        if len(str(code)) > 2:
            getprov = AfgAdmbndaAdm2.objects.all().filter(dist_code=code).extra(select={'code': 'dist_code', 'centroid': 'ST_AsText(wkb_geometry)'})
        else:
            getprov =  AfgAdmbndaAdm2.objects.all().filter(prov_code=code).extra(select={'code': 'dist_code', 'centroid': 'ST_AsText(wkb_geometry)'})
    else:
        getprov = AfgAdmbndaAdm1.objects.all().extra(select={'code': 'prov_code', 'centroid': 'ST_AsText(wkb_geometry)'})

    results = []
    ctroid = ''
    for res in getprov:
        feature = Feature(res.ogc_fid)
        ctroid += res.centroid
        geom = res.wkb_geometry
        geometry = {}
        geometry['type'] = geom.geom_type
        geometry['coordinates'] = geom.coords
        feature.geometry = vw.simplify_geometry(geometry, ratio=0.025)

        feature.properties['code'] = res.code
        results.append(feature)

    geojsondata = {}
    if results:
        geoj = GeoJSON.GeoJSON()
        geojsondata = geoj.encode(results, to_string=False)
        getcentroid = load_wkt(ctroid)
        dcentroid = getcentroid.centroid.wkt
        rpoint = dcentroid.replace('POINT ','')
        rspace = rpoint.replace(' ',', ')
        afirst = rspace.replace('(','')
        alast = afirst.replace(')','')
        fixctr = alast.split(",")
        geojsondata['centroid'] = fixctr

    # string = json.dumps(geojsondata)

    return geojsondata
   